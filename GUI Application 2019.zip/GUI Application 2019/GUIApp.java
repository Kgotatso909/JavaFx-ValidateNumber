import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;
import javafx.scene.text.Text;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class GUIApp extends Application {
    private TextField inputField;

    @Override
    public void start(Stage primaryStage) {
        Label titleLabel = new Label("Property code specification: 10 digits");
        inputField = new TextField();
        Text promptText = new Text("Enter a property code: ");
        Button validBtn = new Button("Validate");

        validBtn.setOnAction(e -> validator());

        GridPane gPane = new GridPane();
        gPane.setVgap(10);
        gPane.setHgap(10);
        gPane.setAlignment(Pos.CENTER);
        gPane.add(titleLabel, 0, 0, 2, 1);
        gPane.add(promptText, 0, 1);
        gPane.add(inputField, 1, 1);
        gPane.add(validBtn, 1, 2);

        Scene scene = new Scene(gPane, 420, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Validate property codes");
        primaryStage.show();
    }

    private void validator() {
        String input = inputField.getText().trim();

        if (input.matches("\\d{10}")) {
            showResults(String.format("%nCode: %s \nOutcome: Valid", input), AlertType.INFORMATION);
        } else if (input.length() != 10) {
            showResults(String.format("%nCode: %s \nOutcome: Invalid - check number of digits", input), AlertType.INFORMATION);
        } else {
            showResults(String.format("%nCode: %s \nOutcome: Invalid - all characters are not digits",input), AlertType.INFORMATION);
        }
    }

    private void showResults(String message, AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle("Validate property codes");
        alert.setContentText(String.format(message, inputField.getText().trim()));
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
